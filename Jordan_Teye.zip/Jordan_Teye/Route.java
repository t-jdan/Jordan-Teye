import java.util.Scanner;

public class Route {
    String Airline;
    String AirlineID;
    String SourceAirport;
    String SourceAirportID;
    String DestAirport;
    String DestAirportID;
    String Stops;

    public Route(String airline, String airlineID, String sourceAirport, String sourceAirportID, String destAirport,
            String destAirportID, String stops) {
        this.Airline = airline;
        this.AirlineID = airlineID;
        this.SourceAirport = sourceAirport;
        this.SourceAirportID = sourceAirportID;
        this.DestAirport = destAirport;
        this.DestAirportID = destAirportID;
        this.Stops = stops;
    }

    public static Route createRoute(String sourceAirportID, String destAirportID){
        Scanner routeFile = FileHandler.useFile("routes.csv");
        Route route = null;
        while(routeFile.hasNextLine()){
            String[] listRoute = routeFile.nextLine().split(",");
            if(sourceAirportID.equals(listRoute[2]) && destAirportID.equals(listRoute[5])){
                route = new Route(listRoute[0], listRoute[1], listRoute[2], listRoute[3], listRoute[4], listRoute[5], listRoute[7]);
                break;
                }
        }return route;       
    }
}

