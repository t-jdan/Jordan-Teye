import java.io.IOException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 * @author Jordan Teye, 40792024
 * 
 */

public class Main{

    // stores data with type Airport using AirportID
    static HashMap<String, Airport> names = new HashMap<>();  

        static ArrayList<String> getAirportIDs(String startCity, String startCountry){
            Scanner data = FileHandler.useFile("airports.csv");
            ArrayList<String> airportIDs = new ArrayList<String>();
            while(data.hasNextLine()){
                String[] dataList = data.nextLine().split(",");
                if(startCity.equals(dataList[2]) && startCountry.equals(dataList[3])){
                    System.out.println("Found Airport ID: " + dataList[0]);
                    airportIDs.add(dataList[0]);
                }
            } return airportIDs;
        }

        static String[] destIDList(String sourceAirportID){
            Set<String> set = new HashSet<String>();
        
            Scanner routesData = FileHandler.useFile("routes.csv");
            while(routesData.hasNextLine()){
                String[] routesList = routesData.nextLine().split(",");
                if(routesList[3].equals(sourceAirportID)){
                    set.add(routesList[5]);
                }
            }
            String[] list = (String[]) set.toArray();
            return list;
        }
        
            static Graph<String> createGraph(){
                Graph<String> graph = new Graph<>();
                
                Scanner routesFile = FileHandler.useFile("routes.csv");
                Scanner airportFile = FileHandler.useFile("airports.csv");
                while(routesFile.hasNextLine()){
                    String[] routesData = routesFile.nextLine().split(",");
                    while(airportFile.hasNextLine()){
                        String[] airportData = airportFile.nextLine().split(",");
                        Airport tempAirport = new Airport(airportData[0], airportData[1], airportData[2], airportData[3]);
                        graph.addNode(tempAirport);
                        names.put(tempAirport.airportID, tempAirport);
                    }
                    if((names.containsKey(routesData[3]) && names.containsKey(routesData[5]))){
                        graph.addConnection(names.get(routesData[3]), names.get(routesData[5]));
                    }
                }
                return graph;
            }

            static ArrayList<String[]> getInput(String filename){
                Scanner file = FileHandler.useFile(filename);
                String[] startLocation = file.nextLine().split(", ");
                String[] endLocation = file.nextLine().split(", ");
                ArrayList<String[]> input = new ArrayList<String[]>();
                input.add(startLocation);
                input.add(endLocation);
                return input;
            }

            // Searches and outputs based on the input file
            static void output(String filename){
                Graph<String> graph = createGraph();
                ArrayList<String[]> input = getInput(filename);

                //get Start Airport
                String startCity = input.get(0)[0];
                System.out.println(startCity);
                String startCountry = input.get(0)[1];
                System.out.println(startCountry);
                ArrayList<String> startAirportIDs = getAirportIDs(startCity, startCountry);
                Airport startAirport = names.get(startAirportIDs.get(0));

                //get Destination Airport
                String destCity = input.get(1)[0];
                System.out.println(destCity);
                String destCountry = input.get(1)[1];
                System.out.println(destCountry);
                ArrayList<String> destAirportIDs = getAirportIDs(destCity, destCountry);
                Airport destAirport =names.get(destAirportIDs.get(1));
                
                // BFS to find connecting Airports
                ArrayList<Airport> destPath = graph.bfs(startAirport, destAirport);
                int num = 1;
                num = num + destPath.size(); // Number of airports to get to destination

                // Path values
                String value = destPath.get(0).ICAO;

                String nameOfFile = startCity.toLowerCase() + "-" + destCity.toLowerCase() + "_output.txt";

        
                FileWriter file = FileHandler.writeToFile(nameOfFile);

                for(int i=0; i<num; i++){
                    try {
                        file.write("Jordan");
                    } catch (IOException e) {
                        System.out.println("An error occured");
                        e.printStackTrace();
                    }

                }



            }

            

            
        
    public static void main(String[] args){
        
        output("testInput.txt");
       
        
        
        
        
    }
}