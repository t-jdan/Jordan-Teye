import java.util.Scanner;

public class Airport{
    String airportID;
    String AirportName;
    String City;
    String Country;
    String IATA;
    String ICAO;
    String Latitude;
    String Longtitude;
    String Altitude;
    String Timezone;
    String DST;
    String tz;
    String type;
    String source;

    
    

    public Airport(String airportID, String airportName, String city, String country) {
        this.airportID = airportID;
        this.AirportName = airportName;
        this.City = city;
        this.Country = country;
    }

    public String getAirportID() {
        return airportID;
    }

    public String getAirportName() {
        return AirportName;
    }

    public String getCity() {
        return City;
    }

    public String getCountry() {
        return Country;
    }


    public static Airport createAirportFromID(String airportID){
        Scanner airportFile = FileHandler.useFile("airports.csv");
        Airport airport = null;
        while(airportFile.hasNextLine()){
            String[] listAirports = airportFile.nextLine().split(",");
            if(airportID.equals(listAirports[0])){
                airport = new Airport(listAirports[0], listAirports[1], listAirports[2], listAirports[3]);
                break;
                }
        }return airport;       
    }

    public static Airport createAirportFromLocation(String airportCity, String airportCountry){
        Scanner airportFile = FileHandler.useFile("airports.csv");
        Airport airport = null;
        while(airportFile.hasNextLine()){
            String[] listAirports = airportFile.nextLine().split(",");
            if(airportCity.equals(listAirports[2]) && airportCountry.equals(listAirports[3])){
                airport = new Airport(listAirports[0], listAirports[1], listAirports[2], listAirports[3]);
                break;
                }
        }return airport;       
    }
    
}

