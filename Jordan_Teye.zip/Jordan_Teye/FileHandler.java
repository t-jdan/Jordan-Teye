import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandler {
    public static Scanner useFile(String filename){
        try{
            File file = new File(filename);
            Scanner info = new Scanner(file);
            return info;
        }catch(FileNotFoundException fnfe){
            System.out.println("An error occurred");
            fnfe.printStackTrace();
        }
        return null;
    }

    static void createFile(String filename){
        try{
            File output = new File("filename");
            if(output.createNewFile()){
                System.out.println("File created: " + output.getName());
            }else{
                System.out.println("File already exists");
            }
        }catch(IOException ioe){
            System.out.println("An error occurred");
        }

    }

    static FileWriter writeToFile(String filename){
        FileWriter myWriter = null;
        try {
            myWriter = new FileWriter(filename);
            System.out.println("Successfully wrote to file " + filename);
        } catch (IOException ioe) {
            System.out.println("An error occurred.");
        }
        return myWriter;
    }
}
