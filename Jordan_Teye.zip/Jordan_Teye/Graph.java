import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

// Use HashMap for Adjacency list Graphs
class Graph <E>{
    int noVertice = 0;
    HashMap<Airport, ArrayList<Airport>> graph = new HashMap<Airport, ArrayList<Airport>>();

    //Adds a node as the key for the HashMap
    //Nodes will store Routes which will be unique
    public void addNode(Airport Node){
        ArrayList<Airport> adjRoutes = new ArrayList<Airport>();
        graph.put(Node, adjRoutes);
        noVertice++;
    }

    //Values of HashMap stores Arrays with connections
    public void addConnection(Airport sourceAirport, Airport destAirport){
        if(graph.containsKey(sourceAirport)){
            graph.get(sourceAirport).add(destAirport);
            graph.get(destAirport).add(sourceAirport);
        }else{System.out.println("");}
    }

    //Removes connections
    public void removeConnection(Airport sourceAirport, Airport destAirport){
        if(graph.containsKey(sourceAirport)){
            graph.get(sourceAirport).remove(destAirport);
            graph.get(destAirport).remove(sourceAirport);
        }else{System.out.println("The Route does not exist");}
    }

    // Searches for Airports that interconnect from chosen Airports
    // and returns an Array of the connected airports
    ArrayList<Airport> bfs(Airport startAirport, Airport destAirport){
        Node node = new Node(startAirport, null);
        ArrayList<Node> frontier = new ArrayList<Node>();
        ArrayList<Airport> successors = new ArrayList<Airport>();
        Set<Airport> explored = new HashSet<Airport>();
        ArrayList<Airport> output = new ArrayList<Airport>();
        
        boolean breakValue = false; // Allows for loop to be broken

        // returns solution if Airport have a direct connection
        if(graph.get(startAirport).contains(destAirport)){
            output = node.solution_path();
            
        }else{
        // Breadth First Search Algorithm
            frontier.add(node);
            while(frontier.size()> 0){
                node = frontier.remove(0);
                explored.add(node.state);
                System.out.println("Popped: " + node.toString());
                successors = graph.get(node.state);
                for(int i = 0; i< successors.size(); i++){
                    Node child = new Node(successors.get(i), node);
                    if((!explored.contains(child.state)) && (!frontier.contains(child))){
                        if(graph.get(child.state).contains(destAirport)){
                            System.out.println("Found solution: " + child.state.AirportName);
                            output = child.solution_path();
                            breakValue = true;
                            break;
                        }
                        frontier.add(child);
                    }
                }
                if(breakValue){
                    break;
                }
            }
        }
        return output;
    }
}