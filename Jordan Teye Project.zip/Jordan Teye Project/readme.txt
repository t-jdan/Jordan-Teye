The program should run with values only changing in the
Input.txt file